import 'package:flutter/material.dart';
import 'package:my_grocery_app/app_drawer.dart';

class MyProfile extends StatelessWidget {
  const MyProfile({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Profile'),
        backgroundColor: Colors.green,
      ),
      drawer: const AppDrawer(),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 20),
            // Profile picture
            const CircleAvatar(
              radius: 60,
              backgroundImage:
                  AssetImage('assets/profile.jpg'), // Add your image to assets
            ),
            const SizedBox(height: 20),
            const Text(
              'Clint Mark M. Caballero',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'clintmark.caballero@normi.edu.ph',
              style: TextStyle(color: Colors.grey),
            ),
            const Divider(height: 40, thickness: 1.2),
            // Profile Information Section
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Personal Information',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 20),
            _buildProfileItem(Icons.phone, 'Phone', '+63 912 345 6789'),
            const SizedBox(height: 10),
            _buildProfileItem(
                Icons.location_on, 'Address', 'Santiago, Philippines'),
            const SizedBox(height: 10),
            _buildProfileItem(Icons.cake, 'Date of Birth', 'February 26, 2005'),
            const SizedBox(height: 10),
            _buildProfileItem(Icons.person, 'Gender', 'Male'),
          ],
        ),
      ),
    );
  }

  // Profile info row widget
  static Widget _buildProfileItem(IconData icon, String title, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.green),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 14,
                        color: Colors.grey,
                        fontWeight: FontWeight.w500)),
                const SizedBox(height: 5),
                Text(value,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
